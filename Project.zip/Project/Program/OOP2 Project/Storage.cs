﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Storage : Product
    {
        public string storageType { get; set; }
        public string memory { get; set; }
        public string rpm { get; set; }
    }
}
