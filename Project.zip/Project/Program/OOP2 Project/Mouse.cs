﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Project
{
    internal class Mouse : Product
    {
        public string type { get; set; }
        public string mouseSwitch { get; set; }
       

    }
}
