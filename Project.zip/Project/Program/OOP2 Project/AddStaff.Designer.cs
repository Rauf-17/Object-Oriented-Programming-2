﻿namespace OOP2_Project
{
    partial class AddStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Back = new System.Windows.Forms.Button();
            this.Signout = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Other_Radio = new System.Windows.Forms.RadioButton();
            this.Female_Radio = new System.Windows.Forms.RadioButton();
            this.Male_Radio = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.TextBox();
            this.Name_txt = new System.Windows.Forms.TextBox();
            this.Add_Staff = new System.Windows.Forms.Button();
            this.dlgt1 = new System.Windows.Forms.TextBox();
            this.Certification1 = new System.Windows.Forms.Label();
            this.dlgt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.LightGray;
            this.Back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Back.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.ForeColor = System.Drawing.Color.Black;
            this.Back.Location = new System.Drawing.Point(37, 759);
            this.Back.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(115, 47);
            this.Back.TabIndex = 22;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Signout
            // 
            this.Signout.BackColor = System.Drawing.Color.LightGray;
            this.Signout.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signout.Location = new System.Drawing.Point(1205, 759);
            this.Signout.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Signout.Name = "Signout";
            this.Signout.Size = new System.Drawing.Size(128, 47);
            this.Signout.TabIndex = 24;
            this.Signout.Text = "Sign  Out";
            this.Signout.UseVisualStyleBackColor = false;
            this.Signout.Click += new System.EventHandler(this.Signout_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::OOP2_Project.Properties.Resources._32officeicons_31_89708;
            this.pictureBox1.Location = new System.Drawing.Point(688, 46);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // Other_Radio
            // 
            this.Other_Radio.AutoSize = true;
            this.Other_Radio.BackColor = System.Drawing.Color.Transparent;
            this.Other_Radio.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Other_Radio.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Other_Radio.Location = new System.Drawing.Point(677, 560);
            this.Other_Radio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Other_Radio.Name = "Other_Radio";
            this.Other_Radio.Size = new System.Drawing.Size(74, 25);
            this.Other_Radio.TabIndex = 38;
            this.Other_Radio.TabStop = true;
            this.Other_Radio.Text = "Other";
            this.Other_Radio.UseVisualStyleBackColor = false;
            // 
            // Female_Radio
            // 
            this.Female_Radio.AutoSize = true;
            this.Female_Radio.BackColor = System.Drawing.Color.Transparent;
            this.Female_Radio.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Female_Radio.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Female_Radio.Location = new System.Drawing.Point(571, 560);
            this.Female_Radio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Female_Radio.Name = "Female_Radio";
            this.Female_Radio.Size = new System.Drawing.Size(83, 25);
            this.Female_Radio.TabIndex = 37;
            this.Female_Radio.TabStop = true;
            this.Female_Radio.Text = "Female";
            this.Female_Radio.UseVisualStyleBackColor = false;
            // 
            // Male_Radio
            // 
            this.Male_Radio.AutoSize = true;
            this.Male_Radio.BackColor = System.Drawing.Color.Transparent;
            this.Male_Radio.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Male_Radio.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Male_Radio.Location = new System.Drawing.Point(479, 560);
            this.Male_Radio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Male_Radio.Name = "Male_Radio";
            this.Male_Radio.Size = new System.Drawing.Size(67, 25);
            this.Male_Radio.TabIndex = 36;
            this.Male_Radio.TabStop = true;
            this.Male_Radio.Text = "Male";
            this.Male_Radio.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label5.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(363, 244);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.label5.MaximumSize = new System.Drawing.Size(133, 123);
            this.label5.MinimumSize = new System.Drawing.Size(13, 12);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label5.Size = new System.Drawing.Size(77, 41);
            this.label5.TabIndex = 35;
            this.label5.Text = "Phone";
            // 
            // Phone
            // 
            this.Phone.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Phone.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone.Location = new System.Drawing.Point(479, 254);
            this.Phone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Phone.Multiline = true;
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(543, 30);
            this.Phone.TabIndex = 34;
            this.Phone.TextChanged += new System.EventHandler(this.Phone_TextChanged);
            this.Phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Phone_KeyPress);
            // 
            // DOB
            // 
            this.DOB.CustomFormat = "yyyy-MM-dd";
            this.DOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DOB.Location = new System.Drawing.Point(479, 496);
            this.DOB.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(265, 22);
            this.DOB.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(325, 415);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.label4.MaximumSize = new System.Drawing.Size(133, 123);
            this.label4.MinimumSize = new System.Drawing.Size(13, 12);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label4.Size = new System.Drawing.Size(112, 41);
            this.label4.TabIndex = 32;
            this.label4.Text = "Password";
            // 
            // Password
            // 
            this.Password.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Password.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.Location = new System.Drawing.Point(479, 420);
            this.Password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Password.Multiline = true;
            this.Password.Name = "Password";
            this.Password.PasswordChar = '*';
            this.Password.Size = new System.Drawing.Size(543, 30);
            this.Password.TabIndex = 31;
            this.Password.TextChanged += new System.EventHandler(this.Password_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(367, 175);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.label3.MaximumSize = new System.Drawing.Size(133, 123);
            this.label3.MinimumSize = new System.Drawing.Size(13, 12);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label3.Size = new System.Drawing.Size(73, 41);
            this.label3.TabIndex = 30;
            this.label3.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(293, 495);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.label2.MaximumSize = new System.Drawing.Size(160, 62);
            this.label2.MinimumSize = new System.Drawing.Size(93, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 49);
            this.label2.TabIndex = 29;
            this.label2.Text = "Date of Birth";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(371, 330);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.label1.MaximumSize = new System.Drawing.Size(133, 123);
            this.label1.MinimumSize = new System.Drawing.Size(13, 12);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.label1.Size = new System.Drawing.Size(70, 41);
            this.label1.TabIndex = 28;
            this.label1.Text = "Email";
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Email.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.Email.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(479, 340);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Email.Multiline = true;
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(543, 30);
            this.Email.TabIndex = 27;
            this.Email.TextChanged += new System.EventHandler(this.Email_TextChanged);
            // 
            // Name_txt
            // 
            this.Name_txt.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Name_txt.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_txt.Location = new System.Drawing.Point(479, 180);
            this.Name_txt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name_txt.Multiline = true;
            this.Name_txt.Name = "Name_txt";
            this.Name_txt.Size = new System.Drawing.Size(543, 30);
            this.Name_txt.TabIndex = 26;
            this.Name_txt.TextChanged += new System.EventHandler(this.Name_txt_TextChanged);
            // 
            // Add_Staff
            // 
            this.Add_Staff.BackColor = System.Drawing.Color.LightGray;
            this.Add_Staff.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Staff.Location = new System.Drawing.Point(897, 714);
            this.Add_Staff.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Add_Staff.Name = "Add_Staff";
            this.Add_Staff.Size = new System.Drawing.Size(128, 47);
            this.Add_Staff.TabIndex = 39;
            this.Add_Staff.Text = "Add Staff";
            this.Add_Staff.UseVisualStyleBackColor = false;
            this.Add_Staff.Click += new System.EventHandler(this.Add_Staff_Click);
            // 
            // dlgt1
            // 
            this.dlgt1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.dlgt1.Font = new System.Drawing.Font("Candara", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dlgt1.Location = new System.Drawing.Point(481, 618);
            this.dlgt1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dlgt1.Multiline = true;
            this.dlgt1.Name = "dlgt1";
            this.dlgt1.Size = new System.Drawing.Size(543, 30);
            this.dlgt1.TabIndex = 40;
            // 
            // Certification1
            // 
            this.Certification1.AutoSize = true;
            this.Certification1.BackColor = System.Drawing.Color.Transparent;
            this.Certification1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Certification1.Font = new System.Drawing.Font("Candara", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Certification1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Certification1.Location = new System.Drawing.Point(293, 618);
            this.Certification1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Certification1.MaximumSize = new System.Drawing.Size(169, 62);
            this.Certification1.MinimumSize = new System.Drawing.Size(93, 49);
            this.Certification1.Name = "Certification1";
            this.Certification1.Size = new System.Drawing.Size(159, 49);
            this.Certification1.TabIndex = 41;
            this.Certification1.Text = "Certification 1.";
            // 
            // dlgt
            // 
            this.dlgt.BackColor = System.Drawing.Color.LightGray;
            this.dlgt.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dlgt.Location = new System.Drawing.Point(936, 656);
            this.dlgt.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dlgt.Name = "dlgt";
            this.dlgt.Size = new System.Drawing.Size(89, 34);
            this.dlgt.TabIndex = 42;
            this.dlgt.Text = "Add Staff";
            this.dlgt.UseVisualStyleBackColor = false;
            this.dlgt.Click += new System.EventHandler(this.dlgt_Click);
            // 
            // AddStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = global::OOP2_Project.Properties.Resources._537844;
            this.ClientSize = new System.Drawing.Size(1371, 836);
            this.Controls.Add(this.dlgt);
            this.Controls.Add(this.Certification1);
            this.Controls.Add(this.dlgt1);
            this.Controls.Add(this.Add_Staff);
            this.Controls.Add(this.Other_Radio);
            this.Controls.Add(this.Female_Radio);
            this.Controls.Add(this.Male_Radio);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Name_txt);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Signout);
            this.Controls.Add(this.Back);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "AddStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddStaff";
            this.Load += new System.EventHandler(this.AddStaff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Signout;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton Other_Radio;
        private System.Windows.Forms.RadioButton Female_Radio;
        private System.Windows.Forms.RadioButton Male_Radio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Name_txt;
        private System.Windows.Forms.Button Add_Staff;
        private System.Windows.Forms.TextBox dlgt1;
        private System.Windows.Forms.Label Certification1;
        private System.Windows.Forms.Button dlgt;
    }
}